<!--/banner-->
	<div class="banner">
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">	<?php getblogridposts("blogs");?></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
			</ol>
			<div class="carousel-inner" role="listbox">
				<div class="carousel-item active" style=" background-image: url(FUNDEN.png);" <?php function convertYoutube($string) {
	return preg_replace(
		"/\s*[a-zA-Z\/\/:\.]*youtu(be.com\/watch\?v=|.be\/)([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i",
		"<iframe width=\"100%\" height=\"100%\" src=\"//www.youtube.com/embed/$2\" allowfullscreen></iframe>",
		$string
	);
}

$text = " https://www.youtube.com/watch?v=PPvkrK1sRpg&t=1s\n\n https://youtu.be/PPvkrK1sRpg";

echo convertYoutube($text);
   ?>>
					<div class="carousel-caption">
						<h3>
							
						</h3>
					</div>
				</div>
				<div class="carousel-item item2" style=" background-image: url(FUNDEN.png);"  <?php 

$text = " https://www.youtube.com/watch?v=ETJruDWjX3o\n\n https://youtu.be/ETJruDWjX3o";

echo convertYoutube($text);
   ?>> 
					<div class="carousel-caption">
						<h3>
					
						</h3>
					</div>
				</div>
				<div class="carousel-item item3" style=" background-image: url(FUNDEN.png);"  <?php 

$text = " https://www.youtube.com/watch?v=brI0qoh4-WQ\n\n https://youtu.be/brI0qoh4-WQ";

echo convertYoutube($text);
   ?>>  >
					<div class="carousel-caption">
						<h3>
					
						</h3>
					</div>
				</div>
				<div class="carousel-item item4" style=" background-image: url(FUNDEN.png);"  <?php 

$text = " https://www.youtube.com/watch?v=hL2hIgW0_2U\n\n https://youtu.be/hL2hIgW0_2U";

echo convertYoutube($text);
   ?>> >
					<div class="carousel-caption">
						<h3>
						
						</h3>
				</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">	Anterior</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Siguiente</span>
			</a>
		</div>
	</div>
	<!--/model-->
	<!--//banner-->