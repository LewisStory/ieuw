
<?php 
include("libs/db_connect.php");
$usernow=getLoggedMemberID(); 

$sqsi=mysqli_query($con, "select * from `membership_users` where memberID='".$usernow."'");
$srowsi=mysqli_fetch_array($sqsi);
$umat=$srowsi['umat'];

?>
<script>


   
<?php
    if($umat >= '2'){
     
        
?>


    const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-info',
        cancelButton: 'btn btn-outline-info'
        },
            buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
   /* title: 'Welcome to Cryptocat :)',
    text: "Create and configure a room / join with your friends",
    imageUrl: 'https://unsplash.it/400/200',
    imageWidth: 400,
    imageHeight: 200,
    imageAlt: 'Cryptocat logo',
    showCancelButton: true,
    confirmButtonText: 'Next...',
    cancelButtonText: 'Skip Intro',
    reverseButtons: true*/
   
  position: 'center-start',

  imageUrl: 'mas.gif',
        imageWidth: 300,
        imageHeight: 200,
 
  title: 'Da click en "Add New"',
  text: 'Y crea una nueva publicacion',
  confirmButtonText: 'Siguiente',
    cancelButtonText: 'Skip Intro',
    reverseButtons: true
 

    
    }).then((result) => {
    if (result.isConfirmed) {
      
        swalWithBootstrapButtons.fire({
            position:  'top-start',
        title: 'Después, regresa y ve tu publicación, junto con la de otros usuarios',
        text: 'En "BLOG ADMIN" Y Ver Sitio',
        imageUrl: 'click2.gif',
        imageWidth: 400,
        imageHeight: 200,
        imageAlt: 'Cryptocat Chat',
        })
        <?php
            mysqli_query($con,"update `membership_users` set umat = '0' where memberID='".$usernow."'");
        ?>
    } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
    ) {
        swalWithBootstrapButtons.fire({
            title: 'Después, regresa ve tu publicación, junto con la de otros usuarios',
        text: 'En "BLOG ADMIN"Y Ver Sitio',
        imageUrl: 'click2.gif',
        imageWidth: 400,
        imageHeight: 200,
        imageAlt: 'Cryptocat Chat',
        })
    }
    })

<?php
    }
?>


</script>