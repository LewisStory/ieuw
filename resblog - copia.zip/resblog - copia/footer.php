<!--footer-->
	<footer>
		<div class="container">
			<div class="row"style= "background-color:  #1D844A;">
				<div class="col-lg-4 footer-grid-agileits-w3ls text-left" >
					<h3>¿Quienes Somos?</h3>
					<p style= "color:  white;">Somos un grupo de personas que tienen familiares desaparecidos de manera forzada o que fueron secuestrados en Nuevo León, también estamos integrados por personas que, sin tener algún familiar desaparecido, se han sumado a nuestra búsqueda...</p>


					<div class="read">
						<a href="about.php" class="btn btn-primary read-m">Leer Más</a>
					</div>
				</div>
				<div class="col-lg-4 footer-grid-agileits-w3ls text-left">

					<div class="tech-btm" >
						<h3>Posts Populares</h3>
					
						<?php getpopularposts("page_hits"); ?>
						
					</div>
				</div>
				<div class="footer-cpy text-center">
				<div class="footer-social">
					<div class="copyrighttop">
						<ul>
							<li class="mx-3">
								<a class="facebook" href="<?php getlinks("links","facebook");?>">
									<i class="fab fa-facebook-f"></i>
									<span style="color:white;">Facebook</span>
								</a>
							</li>
							<li>
								<a class="facebook" href="<?php getlinks("links","twitter");?>">
									<i class="fab fa-twitter"></i>
									<span style="color:white;">Twitter</span>
								</a>
							</li>
							<li class="mx-3">
								<a class="facebook" href="<?php getlinks("links","googleplus");?>">
									<i class="fab fa-youtube" style></i>
									<span style="color:white;">Youtube</span>
								</a>
							</li>
						
						</ul>

					</div>
				</div>
				
			</div>
			</div>
	
		</div>
	</footer>